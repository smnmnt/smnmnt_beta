import './bootstrap.bundle';
import './search';
import './cart';
import './footer';
