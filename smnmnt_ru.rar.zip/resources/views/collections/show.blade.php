@extends('layouts.layout', ['title' => $title])

@section('content')
    <section class="collection">
        <div class="container collection-container">
            @foreach($collection as $coll_un)
                <div class="collection-left-header">
                    <h2 class="collection-title">{{ $coll_un->coll_name }}</h2>
                    <!-- /.collection-title -->
                    <p class="collection-desc">{{ $coll_un->coll_desc }}</p>
                    <div class="standart-card-price-box">
                        <p class="standart-card-price-old">{{ $coll_un->coll_old_price }} ₽</p>
                        <p class="standart-card-price-new">{{ $coll_un->coll_new_price }} ₽</p>
                    </div>
                    <button class="collection-add_to_cart add_to_cart standart-btn" value="{{ $coll_un->coll_id }}">В корзину</button>
                    <a href="{{ route('collections.edit', ['id' => $coll_un->coll_id]) }}" class="standart-btn">Редактировать Исполнителя</a>
                    <form action="{{ route('collections.destroy', ['id' => $coll_un->coll_id]) }}" method="post" onsubmit="return confirm('Удалить Коллекцию?');">
                        @csrf
                        @method('DELETE')
                        <input type="submit" class="standart-btn" value="Удалить">
                        <!-- /.standart-btn -->
                    </form>
                </div>
                @break
            @endforeach
        </div>
        <!-- /.container collection-container -->
    </section>
    <!-- /.collection_section -->
    <section class="collection_catalogue">
        <div class="container collection_catalogue-container">
            @foreach($collection as $coll_un)
                <h2 class="collection_catalogue-title section-title">Коллекция пластинок {{ $coll_un->coll_name }}</h2>
                @break
            @endforeach
            <div class="catalogue-box-cards">
                @foreach($collection as $coll_un)
                    <div class="catalogue-card standart-card">
                        <a href="{{ route('products.show', ['id' => $coll_un->prod_id]) }}">
                            <img src="{{ asset($coll_un->prod_img) ?? asset('./img/icons/question.svg') }}" onError="this.src='{{ asset('./img/icons/question.svg') }}'" alt="album-cover" class="standart-card-img">
                        </a>
                        <div class="standart-card-spec">
                            <a href="{{ route('products.show', ['id' => $coll_un->prod_id]) }}" class="standart-card-album_name">{{ $coll_un->prod_name }}</a>
                            <div class="standart-card-footer">
                                <p class="standart-card-album_year">{{ $coll_un->prod_year }}</p>
                                <div class="standart-card-price-box">
                                    @if($coll_un->prod_sale == 0)
                                        <p class="standart-card-price-new">{{ $coll_un->prod_price }} ₽</p>
                                    @else
                                        <p class="standart-card-price-old">{{ $coll_un->prod_price }} ₽</p>
                                        <p class="standart-card-price-new">{{ $coll_un->prod_sale }} ₽</p>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
        <!-- /.container band_catalogue-container -->
    </section>
    <!-- /.band_catalogue -->
@endsection
