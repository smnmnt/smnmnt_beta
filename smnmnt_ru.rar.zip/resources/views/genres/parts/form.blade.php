@csrf
<div class="row mb-3">
    <label for="prod_name" class="col-md-4 col-form-label">Название жанра
        <input class="form-control" type="text" name="prod_name" placeholder="Название жанра" required value="{{ old('genre_name') ?? $genre_un->genre_name ?? '' }}">
    </label>
</div>
<!-- /.input-group -->
<div class="row mb-3">
    <label for="prod_name" class="col-md-4 col-form-label">Описание жанра
        <input class="form-control" type="text" name="prod_name" placeholder="Описание жанра" required value="{{ old('genre_desc') ?? $genre_un->genre_desc ?? '' }}">
    </label>
</div>
<!-- /.input-group -->
<input type="submit" class="btn btn-primary form-submit" value="Отправить данные">
